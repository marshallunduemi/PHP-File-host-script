== Projec Name: File Upload and Download System,
Theme name: Maguwohost-One-Page-hosting-Template

== Copyright (c) 2017 www.codexpresslab.blogspot.com

Html Created by: http://bootstrapthemes.co


Developed by: https://facebook.com/marshallunduemi



Rights: 
You are permitted to use the resources for any number of personal and commercial projects.
You may modify the resources according to your requirements and include them into works, 
such as websites, applications or other materials intended for sale. No attribution or 
link back to this site is required, however any credit will be much appreciated.


Prohibitions:
You do not have the rights to redistribute, resell, lease, license, sublicense or offer 
files downloaded from http://codexpresslab.blogspot.com to any third party or as a separate attachment 
from any of your work. If you wish to promote my resources on your site, you must link back 
to the resource page where users can find the download and not directly to the download file.


Concerning blog posts, you are free to link to it from any website, 
but you cannot however publish it as it is, without prior consent from http://codexpresslab.blogspot.com

Increase File Size:
To increase Maxium file size, goto upload.php > change where you find this 1024*8068 to any amount

Support More File Types:
To support more file type simply goto the project directory and look for the file name called upload
and lookup to line 10 where you find  $validextensions variable to add your file extension.