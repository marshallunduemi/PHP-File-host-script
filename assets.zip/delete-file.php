<?php

if (isset($_GET['id']) AND ($_GET['id']!='') ) {

	require_once('config.php');

	$id=$_GET['id'];

	$queryUser=$db->query("SELECT * FROM uploads WHERE id='{$id}' ");
	$data=mysqli_fetch_assoc($queryUser);
	$filename=$data['link'];

	$deleteQuery=$db->query("DELETE FROM uploads WHERE id='{$id}' ");

		//$file = ('uploads/'.$filename.''); //get all file names
    	unlink($filename.'/'); //delete fi

    	header('location: files.php');

}

