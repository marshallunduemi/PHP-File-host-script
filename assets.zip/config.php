<?php
//session_start();
//db configuraton details
$dbHost = 'localhost'; //server
$dbUsername = 'root'; //databse user name
$dbPassword = ''; // database user password
$dbName = 'filehost'; // database name

//Connect and select the database
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName); // create new object(instances) for connection

if ($db->connect_error)
{ // check for database error
    die("Connection failed: " . $db->connect_error); // displace error message
}
else {
// success message
}


// file size converter function

function filesize_format($bytes)
{
if($bytes >=1073741824)
{
    $bytes=number_format($bytes/1073741824,2).'GB';
}
elseif($bytes >= 1048576)
{
  $bytes=number_format($bytes/1048576,2).'MB';  
}
elseif($bytes >= 1024)
{
  $bytes=number_format($bytes/1024,2).'KB';
}
elseif($bytes >1 )
{
  $bytes=$bytes.'Bytes';
}
elseif($bytes == 1 )
{
  $bytes=$bytes.'Bytes';
}
else
{
  $bytes='0Bytes';
}
return $bytes;
}


//Check for the type of file browsed so as to represent each file with the appropriate file icon
					function file_format($ext)
					{
					if( $ext == "doc" || $ext == "docx" || $ext == "rtf" || $ext == "DOC" || $ext == "DOCX" )
					{
						$ext = '<img src="images/doc.gif" align="absmiddle" border="0" alt="" />';
					}
					else if( $ext == "pdf" || $ext == "PDF" )
					{
						$ext = '<img src="images/pdf.gif" align="absmiddle" border="0" alt="" />';
					}
					else if( $ext == "txt" || $ext == "TXT" || $ext == "RTF" )
					{
						$ext = '<img src="images/txt.png" align="absmiddle" border="0" alt="" />';
					}
					else if( $ext == "php" )
					{
						$ext = '<img src="images/php.png" align="absmiddle" border="0" alt="" />';
					}
					else if( $ext == "ppt" )
					{
						$ext = '<img src="images/ppt.gif" align="absmiddle" border="0" alt="" width="20px" />';
					}
					else if( $ext == "js" )
					{
						$ext = '<img src="images/general.png" align="absmiddle" border="0" alt="" />';
					}
					else if( $ext == "html" || $ext == "HTML" || $ext == "htm" || $ext == "HTM" )
					{
						$ext = '<img src="images/html.png" align="absmiddle" border="0" alt="" />';
					}
					
					else if( $ext == "mp4" || $ext == "MP4" || $ext == "3GP" || $ext == "3gp" )
					{
						$ext = '<img src="images/video.gif" align="absmiddle" border="0" alt="" />';
					}
					
					else if( $ext == "xls" )
					{
						$ext = '<img src="images/xls.gif" align="absmiddle" border="0" alt="" />';
					}
					
					else if( $ext == "exe" )
					{
						$ext = '<img src="images/setup.gif" align="absmiddle" border="0" alt="" />';
					}
					
					else if( $ext == "zip" )
					{
						$ext = '<img src="images/archive.png" align="absmiddle" border="0" alt="" />';
					}
					else
					{
						$ext = '<img src="images/general.png" align="absmiddle" border="0" alt="" />';
					}
					return $ext;
				}